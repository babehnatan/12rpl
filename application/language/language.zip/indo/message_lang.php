<?php
//indonesia
$lang["menu_test"] = "Test";
