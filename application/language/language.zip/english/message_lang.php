<?php
//english
$lang["menu_test"] = "Test";